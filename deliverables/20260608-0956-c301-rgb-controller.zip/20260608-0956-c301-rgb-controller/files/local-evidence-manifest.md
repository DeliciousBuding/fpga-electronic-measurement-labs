﻿# Local Evidence Manifest

- Generated: 2026-06-08T09:58:10.2742591+08:00
- No device evidence: True
- Recommended gate: `powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify-app.ps1 -AllLocal`
- WebVisualQA: `D:\Code\Quartus\artifacts\web-visual-qa\20260608-094536`
- FPGA simulation: `D:\Code\Quartus\artifacts\fpga-sim\20260608-095032`
- Quartus: `D:\Code\Quartus\artifacts\fpga-quartus\20260608-095039`
- WebVisualQA files: png=11, browserEvents=11, perf=11

## Evidence Files

- `web-visual-qa-summary` - 4289 bytes - SHA256 `2cdd5b652e9b8ad785d74be1c00270c7e47cc6932c6795321c9709309e909ba7` - `D:\Code\Quartus\artifacts\web-visual-qa\20260608-094536\summary.txt`
- `fpga-modelsim-transcript` - 7542 bytes - SHA256 `9405e8c6c3e1ae95fe4887951c20618b26c161ba56c0c994559fe89a12d3d635` - `D:\Code\Quartus\artifacts\fpga-sim\20260608-095032\modelsim-transcript.log`
- `quartus-map-report` - 98478 bytes - SHA256 `76a01aae1f376be0ca6af280495a23f0769b44e5fd74f5a8a9442ff7b44e8281` - `D:\Code\Quartus\artifacts\fpga-quartus\20260608-095039\final-rgb-controller.map.rpt`
- `quartus-map-summary` - 503 bytes - SHA256 `cf5a5d419670f6ad55a64fca8fbafbe01d758c98eaea04f3e526b80fb1bf27fe` - `D:\Code\Quartus\artifacts\fpga-quartus\20260608-095039\final-rgb-controller.map.summary`
- `course-report-markdown` - 21358 bytes - SHA256 `26f31a373a0fc09976fca022931fa4479c7a4a4fb8ba0ffd96e6556f561b7b47` - `C:\Users\Ding\Documents\个人文件\03 课程资料\当前学期\电子测量\综合实验\C301_RGB彩灯蓝牙控制器_综合实验报告.md`
- `course-report-docx` - 312234 bytes - SHA256 `e17e6beacff4b27290e881d09db241175a44f32839753fc9bec1927332ccba00` - `C:\Users\Ding\Documents\个人文件\03 课程资料\当前学期\电子测量\综合实验\C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.docx`
- `course-report-pdf` - 459029 bytes - SHA256 `c5ff1323e0ec83255055cc2b672b9ca5e7a7bade0a6a49c37cc754dc697438c2` - `C:\Users\Ding\Documents\个人文件\03 课程资料\当前学期\电子测量\综合实验\C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.pdf`
- `course-submit-checklist` - 5549 bytes - SHA256 `c19d008fea262494eb03266d11a64619f38f245890c72d8ec48c9045c070d3f9` - `C:\Users\Ding\Documents\个人文件\03 课程资料\当前学期\电子测量\综合实验\C301_RGB彩灯蓝牙控制器_提交检查清单.md`
- `android-release-apk` - 22870279 bytes - SHA256 `a22ac37b82186f3daf7f42085b7570b5f4860e387407763d59ea8c8c84f541b4` - `D:\Code\Quartus\app\build\app\outputs\flutter-apk\app-release.apk`
