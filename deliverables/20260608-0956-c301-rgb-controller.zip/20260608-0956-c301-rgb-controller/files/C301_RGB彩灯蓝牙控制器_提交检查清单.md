# C301 RGB 彩灯蓝牙控制器提交检查清单

更新时间：2026-06-08

## 结论

当前不建议直接提交最终版。工程代码、FPGA 仿真、Quartus 综合、App 本地测试和 Web 视觉 QA 已形成较完整证据，但课程评分说明强调实际操作展示、实验现象图片与文字描述；综合选题也要求蓝牙无线控制和硬件灯效展示。最新版 App 的真机 BLE 连接、现场灯效照片/视频、SignalTap 或示波器波形仍未补齐。

## 已具备材料

- 综合实验报告主稿：`C301_RGB彩灯蓝牙控制器_综合实验报告.md`
- 本地验证 DOCX 草稿：`C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.docx`，已嵌入 6 张本地 WebVisualQA 截图。
- 本地验证 PDF 草稿：`C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.pdf`，已用 `SimSun` 中文字体导出。
- 本地 WebVisualQA 截图副本：`images/web-visual-qa-20260608-015441/`
- 现场证据采集模板：`field-evidence/`，已拆分 BLE 扫描、BLE 连接、LED 灯效、串口记录、波形截图和封面信息 6 类目录。
- 工程交接与证据索引：`D:\Code\Quartus\docs\HANDOFF_2026-06-06.md`
- 可直接使用交付包：`D:\Code\Quartus\deliverables\20260608-0956-c301-rgb-controller.zip`，内含 SOF、arm64 release APK、报告 PDF/DOCX/Markdown、提交检查清单和本地证据 manifest；本机已解包副本在 `D:\Code\Quartus\deliverables\20260608-0956-c301-rgb-controller\files\`。
- GitHub Release 下载页：`https://github.com/DeliciousBuding/fpga-electronic-measurement-labs/releases/tag/c301-rgb-controller-20260608`。
- ModelSim 复验：18 个全链路测试通过，WS2812 timing test 通过。
- Quartus Analysis & Synthesis：0 errors / 0 warnings，资源预算门禁通过。
- 本地全量门禁：`tools\verify-app.ps1 -AllLocal` 已通过；该门禁包含 Flutter analyze/test、WebStatus、WebVisualQA、ModelSim、Quartus Analysis & Synthesis、报告草稿验证和 APK 质量验证，不运行 ADB、APK 安装或真机测试。
- Flutter App 本地验证：`flutter analyze` No issues，`flutter test` 60/60 PASS。
- WebVisualQA：11 张自动截图、console/runtime 门禁和宽松帧采样性能门禁通过，最新目录 `D:\Code\Quartus\artifacts\web-visual-qa\20260608-031759`。
- APK 质量验证：`tools\verify-app.ps1 -SkipAnalyze -SkipTests -ApkQuality` 已通过，release APK 为 21.81 MB / 35 MB，版本 `0.1.0+2026062409` 与 `pubspec.yaml` 一致，未发现 debug kernel blob 或调试样例字符串。
- Quartus SOF：`final-rgb-controller-20260608.sof` 已由 2026-06-08 09:52 full compile 刷新，Quartus full compile 结果为 0 errors / 3 warnings。
- 报告草稿自动验证：`tools\verify-app.ps1 -SkipAnalyze -SkipTests -ReportDraft` 已通过，检查 Markdown、DOCX、PDF、6 张图片引用和关键证据文本。
- 本地证据 manifest：`D:\Code\Quartus\artifacts\local-evidence\20260608-033251\manifest.json` 和 `manifest.md` 已生成，记录 9 个本地证据文件的 SHA256、大小和时间戳；该 manifest 明确标记 `noDeviceEvidence=true`。
- 现场证据门禁：`tools\verify-app.ps1 -SkipAnalyze -SkipTests -FieldEvidence` 可输出当前缺口但不阻塞本地草稿；`-RequireFieldEvidence` 会在 BLE/LED/串口/波形/封面证据缺失时失败，用于最终提交前硬检查。
- App 端 BLE 调试逻辑：ACK/ERR、5 字节状态帧、残留 ACK/ERR 过滤、跨 notify 分片、pending 查询生命周期均有本地测试。

## 提交前必须补齐

- 最新版 APK 在允许测试设备或课堂设备上的 BLE 扫描截图。
- 连接 CH9143 成功截图，需能看到连接状态或调试日志。
- 实际控制 8 颗 WS2812 LED 的照片或视频：静态颜色、呼吸、流水、渐变至少覆盖其中 3 类。
- 现场串口或调试记录：COM 口号、发送字节、返回 ACK/状态帧。
- SignalTap 或示波器波形：至少覆盖 UART RX/TX 或 WS2812 `PIN_T2` 时序之一。
- 报告封面信息：姓名、学号、班级、实验日期、指导教师。
- 若需要提交最终 PDF/DOCX，按课程模板导出并检查图片清晰度和页码范围；当前本地验证 PDF/DOCX 已可读，但仍缺最终封面与硬件证据。

## 可选加分但当前不应硬凑

- 音乐/声控模式：FPGA 端未实现，App 已作为 WIP 禁用项展示，报告中应如实写为待实现，不能当作完成项。
- 多灯同步控制：当前工程未覆盖多板同步，除非后续实际扩展，否则不要写成已完成。
- 自制新 RGB PMOD 板：若没有焊接和实物证据，只能写为设计拓展方向。

## 提交流程建议

1. 现场补齐硬件证据后，把照片、视频截图和波形截图放入 `综合实验/field-evidence/` 对应子目录；需要额外用于报告排版的图片可再复制到 `综合实验/images/`。
2. 更新 `C301_RGB彩灯蓝牙控制器_综合实验报告.md` 的“待补记录”和“待补证据”。
3. 用 `pandoc` 或课程模板重新导出 DOCX/PDF；当前已有 `C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.docx` 和 `C301_RGB彩灯蓝牙控制器_综合实验报告_本地验证草稿.pdf` 可作为版式起点。
4. 打开导出文件人工检查：封面、图片、表格、页码、代码块、路径引用；当前草稿已验证 DOCX 包含 6 张图片，PDF 为 12 页且可抽取关键文本，但尚未按最终封面信息检查。
5. 最终提交前运行 `tools\verify-app.ps1 -SkipAnalyze -SkipTests -RequireFieldEvidence`，确认 6 类现场证据不再缺失。
6. 最后再提交，不用个人手机作为未授权测试设备。
