# C301 综合选题3：RGB 彩灯蓝牙控制器实验报告初稿

> 状态：开发、仿真、Quartus 编译与 App 本地测试内容已据 `D:\Code\Quartus` 当前工程整理；BLE 最新版真机联调、SignalTap 波形截图、现场照片需实测后补入。当前会话不再使用个人手机做测试。

## 一、实验目的

本综合实验基于 Cy4 FPGA 教学平台设计一套无线 RGB 彩灯控制系统。系统通过手机 App 使用 BLE 蓝牙连接 CH9143 PMOD 模块，CH9143 将 BLE 数据透明桥接为 UART 串口字节，FPGA 接收命令后解析颜色、亮度、灯效模式和场景操作，并驱动 8 颗 WS2812 RGB LED 显示静态色、呼吸、流水、渐变等效果。

实验训练目标包括：用 Verilog 完成 FPGA 端完整控制逻辑；掌握 UART 115200 8N1 串口接收、发送与命令解析；掌握 WS2812 单线 NRZ 时序驱动；完成手机 App 到 FPGA 的端到端蓝牙联调；通过 ModelSim、Quartus、串口助手、示波器或 SignalTap 对系统行为进行验证。

## 二、系统总体方案

系统由手机 App、CH9143 BLE PMOD、Cyclone IV FPGA 和 WS2812 LED 灯带组成。手机端使用 Flutter 自研 App，提供颜色、亮度、效果、场景和设置页面；蓝牙层使用 CH9143 的 FFF0 服务，其中 FFF2 为 App 写入特征值，FFF1 为 FPGA 返回通知特征值；FPGA 端通过 `rx_din` 接收 UART 字节，通过 `tx_dout` 返回 ACK 或状态帧。

```text
Flutter App
  -> BLE FFF2 写入
  -> CH9143 BLE-UART 透传
  -> FPGA UART RX / cmd_parser
  -> 灯效引擎 / scene_store / ws2812_driver
  -> WS2812 RGB LED

FPGA UART TX
  -> CH9143 BLE-UART 透传
  -> BLE FFF1 Notify
  -> Flutter App 状态同步与调试日志
```

关键硬件参数如下：

| 项目 | 参数 |
| --- | --- |
| FPGA | Cyclone IV E EP4CE15F17C8 |
| 系统时钟 | 50 MHz，`clk = PIN_E1` |
| 复位 | 低电平有效，`nrst = PIN_L2` |
| UART | 115200 Baud，8N1，分频系数 434 |
| CH9143 TX 到 FPGA RX | `rx_din = PIN_B11` |
| FPGA TX 到 CH9143 RX | `tx_dout = PIN_D6` |
| WS2812 数据线 | `led_din = PIN_T2` |
| 调试输出 | `tx_busy_flag_qn = PIN_A7` |

注意：`PIN_D5` 是早期错误 UART RX 接线，当前设计与实测文档均采用 `PIN_B11`。

## 三、通信协议设计

FPGA 与手机 App 之间采用字节级命令协议。App 发出的每条命令以命令码开头，后接固定长度参数；除查询状态外，FPGA 返回 `0xAA` 表示执行成功，返回 `0xEE` 表示命令错误或参数错误。

| 命令 | 参数 | 功能 | FPGA 返回 |
| --- | --- | --- | --- |
| `0x10` | `R G B` | 设置静态颜色 | `0xAA` / `0xEE` |
| `0x11` | `Brightness` | 设置亮度 0-255 | `0xAA` / `0xEE` |
| `0x20` | `Mode` | 设置模式 0-4 | `0xAA` / `0xEE` |
| `0x21` | `FlowSpeed` | 设置流水速度 | `0xAA` / `0xEE` |
| `0x22` | `BreathPeriod` | 设置呼吸周期 | `0xAA` / `0xEE` |
| `0x30` | `SceneSlot` | 保存场景 0-7 | `0xAA` / `0xEE` |
| `0x31` | `SceneSlot` | 读取场景 0-7 | `0xAA` / `0xEE` |
| `0xFF` | 无 | 查询当前状态 | `[mode][R][G][B][Brightness]` |

App 端已将协议帧构造集中在 `Cmd` 常量模型中，测试用例逐字节验证了 8 类命令的帧格式。BLE 写入采用串行化锁，避免多个滑块快速操作时并发写入；颜色、亮度、速度等连续滑块命令使用 48 ms 节流，只发送窗口内最新值，以兼顾高刷屏滑动手感和串口链路负载。

## 四、FPGA 端设计

FPGA 工程位于 `D:\Code\Quartus\final-rgb-controller`。顶层模块 `rgb_controller_top.v` 集成 UART 接收、命令解析、UART 返回、灯效生成、场景存储和 WS2812 驱动，当前综合路径共 9 个 Verilog 模块：

| 模块 | 功能 |
| --- | --- |
| `rgb_controller_top.v` | 顶层连线与全局状态输出 |
| `uart_rx_byte.v` | 115200 Baud UART 接收，中心采样 |
| `uart_tx_byte.v` | 115200 Baud UART 发送，ACK/状态返回 |
| `cmd_parser.v` | 7 状态命令 FSM，解析命令并调度控制寄存器 |
| `ws2812_driver.v` | WS2812 NRZ 编码，驱动 8 颗 LED |
| `breath_engine.v` | 64 项正弦 LUT 呼吸亮度 |
| `flow_engine.v` | 单灯追逐流水效果 |
| `gradient_engine.v` | 128 项彩虹渐变 LUT |
| `scene_store.v` | 8 个场景槽保存和读取 |

说明：`rgb_pwm_core.v` 是早期 3 通道 PWM 参考实现，当前 WS2812 方案不实例化它，也已从 QSF 与 ModelSim 全链路编译列表移除；当前 LED 输出路径为 `rgb_controller_top` -> `ws2812_driver` -> `led_din`。

命令解析 FSM 以 UART 字节到达为触发，根据命令码决定后续参数字节数。接收完整参数后更新颜色、亮度、模式、速度或场景存储，并启动 UART TX 返回 ACK。`0xFF` 查询命令直接返回 5 字节状态帧，App 收到后同步 UI 状态。

WS2812 驱动采用单线 NRZ 编码，一位约 1.25 us，24 位构成一颗 LED 的 GRB 数据，8 颗 LED 顺序发送后保持低电平复位间隔。灯效引擎输出 RGB 或亮度调制结果，最后交给 WS2812 驱动编码输出。

## 五、手机 App 设计

手机 App 位于 `D:\Code\Quartus\app`，使用 Flutter + Riverpod + flutter_blue_plus 开发。当前界面包含 4 个主页面：

| 页面 | 功能 |
| --- | --- |
| LED | 颜色预设、RGB 三通道滑块、亮度滑块、当前 LED 预览 |
| Effect | 静态、呼吸、流水、渐变 4 类已实现模式，速度/周期调节；音乐/声控入口标记为 WIP 且禁用 |
| Scene | 8 个场景槽，点击读取、长按保存 |
| Settings | 语言、主题、BLE 状态、调试日志 |

App 支持中英文切换、Material 3 主题、动态色、BLE 扫描连接、自动查询状态和调试日志。连接成功后自动发送 `0xFF` 查询 FPGA 当前状态，避免 App UI 与板上状态不一致；状态查询在发送前进入接收状态，避免真机快速返回的 5 字节状态帧被 parser 丢弃。场景页长按保存后会将该槽位写入本地 `SharedPreferences`，重启 App 后仍可显示已保存标记；实际场景数据仍保存在 FPGA 端 `scene_store`。

## 六、仿真、编译与测试记录

### 6.1 ModelSim 仿真

`final-rgb-controller/sim/tb_rgb_controller.v` 覆盖了颜色、亮度、模式、速度、场景保存/读取、状态查询和错误命令等路径，当前记录为 18 个测试用例全部通过。`final-rgb-controller/sim/tb_ws2812_driver.v` 独立覆盖 WS2812 输出时序，逐 bit 检查 `T0H=18` 个 50 MHz 时钟周期、`T1H=35` 个时钟周期、每 bit 共 `63` 个周期、8×24 bit 顺序输出以及 `RESET_CYCLES=3000` 的低电平复位间隔。2026-06-08 复验 transcript 为 `D:\Code\Quartus\artifacts\fpga-sim\20260608-001706\modelsim-transcript.log`，结果包含 `ALL 18 TESTS PASSED` 与 `WS2812 TIMING TEST PASSED`。

待插图：ModelSim 波形截图，重点标出 UART RX 字节、`cmd_parser` 状态、ACK TX、状态帧返回以及 WS2812 输出启动时序。

### 6.2 Quartus 编译

Quartus 工程 `final-rgb-controller.qpf` 已完成综合、布局布线和 Assembler。`output_files/final-rgb-controller.flow.rpt` 显示 Flow Status 为 Successful，时间为 2026-06-04 13:36；`fit.summary` 显示 Fitter Successful，逻辑资源 1,361 / 15,408（9%），管脚 5 / 166（3%），嵌入式 9-bit multiplier 6 / 112（5%），目标器件 EP4CE15F17C8。2026-06-08 复验 Analysis & Synthesis：0 errors / 0 warnings，并启用资源预算门禁，资源为 1,461 / 2,000 LEs、957 / 1,200 registers、5 / 8 pins、6 / 8 个 9-bit multiplier；报告路径为 `D:\Code\Quartus\artifacts\fpga-quartus\20260608-001730\final-rgb-controller.map.rpt`。

待补证据：`output_files/final-rgb-controller.flow.rpt` 或 Quartus 编译截图。

### 6.3 串口协议测试

通过 CH9143 虚拟串口 COM 口测试 8 个命令码，`0x10` 到 `0x31` 返回 ACK，`0xFF` 返回 5 字节状态帧。该测试证明 FPGA UART RX、命令 FSM、UART TX 和 CH9143 透明桥接链路可工作。

待补记录：上课现场 COM 口号、串口助手截图、发送字节与返回字节清单。

### 6.4 Flutter App 测试

当前 App 自动化验证包括：

| 测试 | 结果 |
| --- | --- |
| `flutter analyze` | No issues found |
| `flutter test` | 55 tests passed |
| `tools/verify-app.ps1 -SkipAnalyze -SkipTests -FpgaSim` | ModelSim 18/18 tests passed + WS2812 timing test passed，transcript：`D:\Code\Quartus\artifacts\fpga-sim\20260608-001706\modelsim-transcript.log` |
| `tools/verify-app.ps1 -SkipAnalyze -SkipTests -QuartusMap` | Analysis & Synthesis successful, 0 errors / 0 warnings，资源预算门禁通过：1,461 / 2,000 LEs、957 / 1,200 registers、5 / 8 pins、6 / 8 个 9-bit multiplier |
| 协议帧构造测试 | 8 类命令帧 byte-for-byte 通过 |
| 场景保存持久化测试 | `SharedPreferences` 读取/写回通过 |
| 窄屏布局回归 | Color 页 280 px 宽、Scanner 长设备名 280 px 宽均无 Flutter layout exception |
| 交互布局回归 | MainShell 底栏纯图标、真实滚动阈值隐藏/恢复，底栏隐藏使用平移/淡出动画而非高度压缩，小幅滚动抖动不触发隐藏，Effect 音乐/WIP 禁用，Scene 8 场景窄屏渲染均通过 Widget 测试 |
| Scanner 诊断回归 | fake BLE 页面级测试覆盖失败诊断卡、`BLUETOOTH_SCAN` 错误、协议状态、复制快照和 debug 样例高亮 |
| Settings 诊断回归 | fake BLE 页面级测试覆盖高级诊断展开、协议状态、复制快照、运行诊断和清空日志 |
| LED 预览几何回归 | `computeLedStripDotLayout()` 覆盖 160/216/360 px 宽度，断言 8 个 LED 点和光晕均不重叠 |
| BLE 调试回归 | 扫描有超时边界，连接失败统一清理，状态查询在真实 BLE write 前一刻进入接收态并等待状态帧或 2s timeout，FFF2 支持 writeWithoutResponse/write fallback；`BleRxParser` 行为测试覆盖 ACK/ERR、状态帧前残留 ACK/ERR 过滤、partial frame timeout 计数、跨 notify 分片、状态帧内合法 `0xAA/0xEE` 数据和同包状态帧后 ACK；`BleStatusQueryTracker` 测试覆盖 pending 查询成功、失败、替换和幂等完成 |
| Web 构建与浏览器预览 | `flutter build web` 通过；`tools/verify-app.ps1 -SkipAnalyze -SkipTests -WebVisualQA` 通过，自动截图 1280x720、390x844、390x844 滚动后、390x844 下滑再上滑回顶、390x844 Scanner 空态、390x844 Scanner debug 样例、390x844 灯效、390x844 情景、390x844 设置、460x900、460x900 滚动后，并校验非空渲染、滚动差异、回顶相似度、底部导航切页差异、Scanner debug 样例差异与 console/runtime error，未发现 8 LED 点重叠、底栏文字回退或滚动时 AppBar 内容穿透 |

2026-06-08 最新本地复验：`tools/verify-app.ps1 -AllLocal` 通过，`flutter analyze` No issues，`flutter test` 61/61 PASS；新增 `BleRxParser` 与 `BleStatusQueryTracker` 行为测试后，BLE 收包解析、残留 ACK/ERR 过滤、跨 notify 分片、状态查询 timeout 计数和 pending 查询 Future 生命周期可以在无手机环境下重复验证。`queryStatus()` 已收紧为在真实 BLE write 前一刻进入接收态，并等待状态帧或 2s timeout 后返回，避免连接诊断过早显示 ready；断连、teardown 或页面销毁会完成 pending 查询，避免 Future 悬挂。UI 动效方面，底部栏隐藏改为滚动阈值触发，避免小幅滑动时立刻弹出/隐藏；预设色块去掉嵌套 scale/fade 动画，Color/Effect 预览周期统一到全局 `AppMotion.effectPreviewCycle`；AppBar 改为不透明 surface，避免滚动时内容透到标题后方。自动 WebVisualQA 最新证据目录为 `D:\Code\Quartus\artifacts\web-visual-qa\20260608-031759`，共 11 张截图，其中 390x844 下滑截图与首屏有差异、下滑再上滑回顶截图与首屏相似，Scanner 空态图显示“未发现设备”，Scanner debug 图显示 `CH9143 RGB Controller` 与 `UART-FFF0-LED` 位于前两位并带 `RGB` 标记，console/runtime error 门禁通过；每个视口还生成 `*.perf.json`，11 个视口帧采样均约 `avgFrameMs=16.67`、`p95FrameMs=16.7-16.8`、`maxFrameMs=16.7-16.8`，用于捕获明显卡顿、长任务或渲染停滞。`tools/verify-app.ps1 -AllLocal` 同轮还通过 ModelSim 仿真（transcript：`D:\Code\Quartus\artifacts\fpga-sim\20260608-032306\modelsim-transcript.log`）、Quartus Analysis & Synthesis（报告：`D:\Code\Quartus\artifacts\fpga-quartus\20260608-032314\final-rgb-controller.map.rpt`）、报告草稿验证、APK 质量验证和本地证据 manifest 生成；manifest 路径为 `D:\Code\Quartus\artifacts\local-evidence\20260608-033251\manifest.json`，记录 9 个证据文件的大小、时间戳和 SHA256。当前 `app-release.apk` 为 21.81 MB / 35 MB，版本为 `0.1.0+2026062409`，`libapp.so` 与 `libflutter.so` 仅位于目标 `arm64-v8a`，未发现 debug Dart kernel blob 或调试样例字符串。`tools/web-visual-qa.ps1` 已使用绝对 `resolvedOutDir` 写入截图、日志、Chrome profile、summary 和 perf metrics，避免相对输出目录导致 CDP 启动失败。该轮复验未使用个人手机、ADB、安装 APK、真机截图或 BLE 实机命令。

现场证据目录已补充为 `field-evidence/`，按 `01-ble-scan`、`02-ble-connect`、`03-led-effects`、`04-serial-log`、`05-waveform`、`06-cover-info` 六类收集最终提交材料。`tools/verify-app.ps1 -SkipAnalyze -SkipTests -FieldEvidence` 用于生成当前缺口状态；`tools/verify-app.ps1 -SkipAnalyze -SkipTests -RequireFieldEvidence` 会在六类证据未补齐时失败，应作为最终提交前的硬检查。

待补记录：最新版 APK 真机 BLE 扫描截图、连接成功截图、实际控制 LED 效果照片或视频。当前已有旧版手机 smoke 只能说明旧版 App 可启动，不能作为最新版 UI/BLE 结论；当前 `field-evidence` 状态为 0/6 完成，仍缺 BLE 扫描、BLE 连接、LED 灯效、串口记录、波形截图和封面信息。

## 七、联调步骤与操作规范

1. 给 Cy4 板上电，确认 CH9143 PMOD 接线方向正确，FPGA `rx_din` 接 CH9143 TX，`tx_dout` 接 CH9143 RX。
2. 使用 Quartus Programmer 下载 `final-rgb-controller/output_files/final-rgb-controller.sof`。
3. 打开手机 App，进入 BLE 扫描页面，开启蓝牙权限并扫描 CH9143 设备。
4. 连接成功后观察 App 调试日志是否出现连接成功、`TX: ff` 和 5 字节状态返回。
5. 在 LED 页面拖动 RGB 与亮度滑块，观察灯色和亮度是否跟随变化。
6. 在 Effect 页面切换呼吸、流水、渐变模式，并调节速度或周期。
7. 在 Scene 页面长按任一场景保存，再点击读取，观察是否恢复对应颜色和模式。
8. 若使用串口助手旁路测试，配置 115200、8N1、无校验，按协议表发送十六进制字节。

安全与规范：上电前检查 PMOD 插接方向；示波器地夹必须接开发板 GND，不得夹到信号脚；测 WS2812 数据线时探头接 `PIN_T2`，建议时基约 2 us/div、电压约 2 V/div、上升沿触发；下载 SOF 前确认工程目标器件为 EP4CE15F17C8。

## 八、问题与改进

已解决问题：

- UART RX 早期误接 `PIN_D5`，已改为 `PIN_B11`。
- BLE 写入可能并发，App 端加入写入锁。
- 滑块快速拖动会产生大量命令，App 端加入 48 ms 节流。
- 查询状态可能因真机快速返回而被 parser 丢弃，App 端调整为发送 `0xFF` 前先进入状态收集，并忽略状态帧前的残留 ACK/ERR。
- Scanner 页面单文件过长，已拆分为 Header、空状态、设备项和 BLE 关闭态组件。
- `sceneSaved` 重启丢失，已持久化到 `SharedPreferences`。
- 连接失败路径已统一清理 notify 订阅、连接订阅、TX 特征、parser 状态，避免旧连接状态污染下一次连接。
- FFF2 写特征已支持 `writeWithoutResponse` 优先、普通 `write` 回退，并在调试日志记录实际写入模式。
- 真机 smoke 诊断已增加严格版本门禁；若手机安装版本低于源码版本，不再把旧版截图/日志当作新版 UI/BLE 证据。
- Scanner 设备卡片已对长 BLE 名称和长 RemoteId 做单行省略，并通过 280 px 窄屏 widget 测试。
- 底部栏滚动隐藏已接入主 Shell 的垂直滚动阈值监听，向下累计滑动后隐藏，向上滑动或回到顶部恢复，小幅抖动不触发隐藏，避免设置项成为无效开关。
- 底部栏隐藏动效已改为 `AnimatedSlide + AnimatedOpacity`，隐藏时平移淡出并用 `IgnorePointer` 防止误触，避免滚动时底栏高度瞬间压缩造成卡顿感。
- Color / Effect 预览动画周期已统一到 `AppMotion.effectPreviewCycle`，预设色块去掉嵌套 scale/fade 动画，滚动时 AppBar 使用不透明 surface 避免内容穿透标题栏。
- BLE 扫描和连接前已主动请求 Android Nearby devices / Bluetooth 运行时权限；扫描、连接和写入异常也会分类为 `BLUETOOTH_SCAN`、`BLUETOOTH_CONNECT`、定位服务/权限或附近设备权限问题并写入调试快照。
- BLE 收包状态机已从 `BLEService` 私有逻辑抽出为 `BleRxParser`，状态查询 Future 生命周期已抽出为 `BleStatusQueryTracker`，避免只能靠源码字符串检查；状态查询前残留 ACK/ERR、跨 notification 分片、5 字节状态帧、状态帧内合法 `0xAA/0xEE` 数据、partial frame timeout 计数和 pending 查询完成均有本地行为测试。
- Scanner 页面在 Web 调试预览中默认不自动触发平台 BLE scan，可通过 debug science 样例稳定查看 CH9143/UART 设备排序和目标高亮；移动端仍保留进入扫描页自动扫描行为。

待改进问题：

- SignalTap 波形捕获尚未完成。
- BLE 最新版真机联调记录尚未补入报告；当前不再使用个人手机测试，后续需在允许的测试设备或课堂设备上完成。
- 音乐模式在 FPGA 端未实现，当前 App 端仅作为 WIP 展示。
- Flutter Web 平台目录已纳入工程，`web/index.html` / `web/manifest.json` 已改为项目元数据；当前 Web 构建存在 CupertinoIcons 字体提示但构建成功，源码未发现直接引用，后续如引入 Cupertino 图标需补依赖或替换图标。
- 为避免误用个人手机，当前 ADB 诊断和安装脚本已增加默认保护；未重新授权前不运行个人手机 ADB、安装、截图、`device-smoke` 或 BLE 实机测试。
- FPGA 查表模块已从时序块初始化数组改为 `function + case` 常量查表，移除未使用寄存器并配置 Quartus 并行处理器数；当前 Analysis & Synthesis 已降至 0 warning。
- FPGA 自动化验证新增 WS2812 独立时序 testbench，并把 Quartus 0 warning 与资源上限纳入硬门禁；后续若时序常量、LED 数量或资源规模异常变化，会在本地验证阶段直接失败。

## 九、本地 App/Web 验证截图

以下截图来自 `tools/verify-app.ps1 -SkipAnalyze -SkipTests -WebVisualQA` 的本地 Flutter Web 预览，不替代最新版真机 BLE 连接和现场 LED 灯效照片，但可作为 App 界面、滚动、调试页和多页面布局的自动化验证证据。

![LED 控制页首屏，8 颗 LED 预览为 4×2 布局](images/web-visual-qa-20260608-015441/mobile-390.png){width=45%}

图 1：LED 控制页首屏。本地 Web 预览显示 8 颗 LED 点位无重叠，底部导航为纯图标。

![LED 控制页滚动后，AppBar 不透出正文内容](images/web-visual-qa-20260608-015441/mobile-390-scroll.png){width=45%}

图 2：LED 控制页滚动后。滚动时 AppBar 后方不再透出连接横幅或卡片文字，底栏随下滑隐藏。

![扫描页调试样例设备列表](images/web-visual-qa-20260608-015441/mobile-390-scanner-debug.png){width=45%}

图 3：扫描页 debug 样例。`CH9143 RGB Controller` 和 `UART-FFF0-LED` 排在前两位并显示 RGB 标记，用于无硬件环境下验收扫描列表 UI 和目标排序。

![灯效页本地预览](images/web-visual-qa-20260608-015441/mobile-390-effect.png){width=45%}

图 4：灯效页。页面保留当前模式的单个预览区域，音乐/声控模式未作为已实现硬件功能发送。

![情景模式页本地预览](images/web-visual-qa-20260608-015441/mobile-390-scene.png){width=45%}

图 5：情景模式页。本地截图用于检查 8 个场景卡片在窄屏下的布局、保存标记和 active 视觉空间。

![设置页本地预览](images/web-visual-qa-20260608-015441/mobile-390-settings.png){width=45%}

图 6：设置页。高级诊断默认折叠，BLE 状态和调试入口保持在可见范围内。

## 十、待核对清单

- 上课实际 BLE 设备名、MAC/RemoteId、连接耗时。
- 现场 COM 口号与串口助手返回字节截图。
- SignalTap 触发信号选择、采样深度、触发条件和波形截图。
- WS2812 实测波形高低电平宽度。
- 现场灯效照片：静态红/绿/蓝、呼吸、流水、渐变、场景保存读取。
- 最新版 APK 安装、启动、BLE 连接证据：当前 vivo 安装确认链路曾返回 `INSTALL_FAILED_ABORTED: User rejected permissions`，且当前会话停止使用个人手机测试。
- 报告封面信息：姓名、学号、班级、实验日期、指导教师。
- 最终提交前需补齐 `field-evidence/` 六类目录，并通过 `-RequireFieldEvidence` 硬门禁。
